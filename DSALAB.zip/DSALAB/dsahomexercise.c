#include <stdio.h>
int main()
{
    int n;
    printf("enter the elements of the array:\n");
    scanf("%d",&n);
    int a[100];
    printf("enter the elements of the array:\n");
    int i,temp,j;
    for(i=0;i<n;i++)
    {
        scanf("%d",a[i]);
    }
    for(i=0;i<n;i++)
    {
        for(j=i+1;j; j < n; j++)
        {
            if (arr[i]%2!=0 && arr[j]%2==0)
            {
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
                break;
            }
        }
    }
    printf("THE ARRAY OF EVEN ELEMENTS FOLLOWED BY ODD ELEMENTS IS\n");
    for (i = 0; i < n; i++)
    {
        printf("%d ", arr[i]);
    }
    return 0;
}
)