#include<stdio.h>
int main()
{
    int n;
    printf("enter the number of characters:\n");
    scanf("%d",&n);
    int k;
    k=2*n;
    char str1[n],str2[n],str3[k];
    printf("enter two strings of same size:\n");
    printf("enter the first string:\n");
    scanf("%s",&str1);
    printf("enter the second string:\n");
    scanf("%s",&str2);
    int j=0,p=1;
    for(int i=0;i<k;i=i+2)
    {
        str3[i]=str1[j];
        str3[p]=str2[j];
        j++;
        p=p+2;
    }
    printf("the new string which is the combination of other two string is:\n");
    printf("%s",str3);
    return 0;
}