#include <stdio.h>
int main()
{
    int n;
    printf("enter the limit:");
    scanf("%d",&n);
    int a[n];
    printf("enter the elements of the array:\n");
    int i,j;
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(a[j]>a[i])
            {
                a[i]=a[j];
                break;
            }
        }
    }
    printf("the new array is:\n");
    for(i=0;i<n;i++)
    {
        printf("%d ",a[i]);
    }
    return 0;
}