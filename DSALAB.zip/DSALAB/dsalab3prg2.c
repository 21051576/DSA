#include<stdio.h>
void polynomial()
{
    int degree;
    printf("enter the degree of the polynomial:\n");
    scanf("%d",&degree);
    degree=degree+1;
    int poly[degree];
    printf("enter the coefficients of the polynomial:\n");
    int i;
    for(i=0;i<degree;i++)
    {
        scanf("%d",&poly[i]);
    }
    //printing the polynomial
    for(i=0;i<degree;i++)
    {
        printf("%dx^%d ",poly[i],i);
    }
}
int main()
{
    polynomial();
    return 0;
}