#include<stdio.h>
int main()
{
    int n;
    printf("ENTER THE LIMIT OF THE ARRAY:\n");
    scanf("%d",&n);
    int number[n];
    int i;
    printf("ENTER THE NUMBERS OF THE ARRAY:\n");
    for(i=0;i<n;i++)
    {
        scanf("%d",&number[i]);
    }
    int max,min;
    max=number[0];
    min=number[0];
    for(i=0;i<n;i++)
    {
        if(number[i]<min){
            min=number[i];
        }
    }
    for(i=0;i<n;i++)
    {
        if(number[i]>max){
            max=number[i];
        }
    }
    printf("THE SMALLEST NUMBER IS:%d\n",min);
    printf("THE LARGEST NUMBER IS:%d\n",max);
    return 0;
}