#include<stdio.h>
int main()
{
    int n;
    printf("ENTER THE LIMIT OF THE ARRAY:\n");
    scanf("%d",&n);
    int arr[n];
    printf("ENTER THE ELEMENTS OF THE ARRAY:\n");
    int i;
    for(i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }
    int no,flag=0;
    printf("ENTER THE NUMBER TO BE SEARCHED:\n");
    scanf("%d",&no);
    for(i=0;i<n;i++)
    {
        if(arr[i]==no)
        {
            flag++;
            break;
        }
    }
    if (flag==1)
    {
        printf("THE NUMBER YOU HAVE ENTERED IS PRESENT\n");
    }
    else{
        printf("SORRY!! NUMBER NOT PRESENT");
    }
    return 0;
}