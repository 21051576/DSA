#include<stdio.h>
int main()
{
  int r,c;
  printf("Enter no of rows:\n");
  scanf("%d",&r);
  printf("enter no of columns:\n");
  scanf("%d",&c);
  int arr[r][c];
  printf("Enter elements of matrix:\n");
  for(int i=0;i<r;i++)
  {
    for(int j=0;j<c;j++)
    {
      scanf("%d",&arr[i][j]);
    }
  }
  int k=0;//counter to calculate the no of non zero elements
  for(int i=0;i<r;i++)
  {
    for(int j=0;j<c;j++)
    {
      if(arr[i][j]!=0){
        k++;
      }
    }
  }
  if(k<(r*c))
  {
    printf("the given matrix is a sparse matrix\n");
  }
  else{
    printf("the given matrix is not a sparse matrix\n");
  }
}