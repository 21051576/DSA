#include<stdio.h>
int main()
{
    int m,n,i,j;
    printf("enter the no of rows and columns:\n");
    scanf("%d",&m);
    scanf("%d",&n);
    int a[m][n];
    printf("enter the elements of sparse matrix:\n");
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    int c=0;
    for(int i=0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(a[i][j]!=0)
            {
                c++;
            }
        }
    }
    int t[c+1][3];
    printf("printing the sparse matrix befor modifying:\n");
    for(int i=0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
            printf("%d ",a[i][j]);
        }
        printf("\n");
    }
    t[0][0]=m;
    t[0][1]=n;
    t[0][2]=c;
    int p=0;
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            if(a[i][j]!=0)
            {
                p++;
                t[p][0]=i;
                t[p][1]=j;
                t[p][2]=a[i][j];
            }
        }
    }
    printf("printing the triplet form:\n");
    for(int i=0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
            printf("%d ",t[i][j]);
        }
        printf("\n"); 
    }
   