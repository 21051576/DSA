#include <stdio.h>
#define max 50
void polynomial()
{
    int d1, d2, d3;
    int poly3[max];
    printf("Enter the degree of 1st polynomial");
    scanf("%d",&d1);
    d1+=1;
    int poly1[d1];
    printf("Enter the coefficient of first polynomial");
    for(int i=0;i<d1;i++)
      scanf("%d",&poly1[i]);
    printf("Enter the degree of 2nd polynomial");
    scanf("%d",&d2);
    d2++;
    int poly2[d2];
    printf("Enter the coefficient of second polynomial");
    for(int i=0;i<d2;i++)
      scanf("%d",&poly2[i]);
    if(d1>=d2)
    {
      d3=d1;
      
      for(int i=0;i<d1;i++)
        poly3[i]=poly1[i];
      for(int i=0;i<d2;i++)
        poly3[i]+=poly2[i];
    }
    else
    {
      d3=d2;
      //int poly3[degree2];
      for(int i=0;i<d2;i++)
        poly3[i]=poly2[i];
      for(int i=0;i<d1;i++)
        poly3[i]+=poly1[i];
    }
    printf("\nFirst polynomial:\t");
    for(int i=0;i<d1;i++)
      printf("%dx^%d \t",poly1[i],i);
    printf("\nsecond polynomial:\t");
    for(int i=0;i<d2;i++)
      printf("%dx^%d \t",poly2[i],i);  
    printf("\nSum polynomial:\t");
    for(int i=0;i<d3;i++)
      printf("%dx^%d \t",poly3[i],i);  
}
int main()
{
    polynomial();
    return 0;
}