#include<stdio.h>
struct employee
{
    char gender;
    char emp_name[50];
    char designation[50];
    char department[50];
    int salary;
    int gross;
};
int main()
{
    int n;
    printf("enter the limit:\n");
    scanf("%d",&n);
    struct employee e[n];
    int i;
    for(i=0;i<n;i++)
    {
        printf("Enter the eployee gender as M Or F Or O\n");
        scanf("%s",&e[i].gender);
        printf("Enter the employee name:\n");
        scanf("%s",&e[i].emp_name);
        printf("enter the designation of the employee\n");
        scanf("%s",&e[i].designation);
        printf("enter the department:\n");
        scanf("%s",&e[i].department);
        printf("enter the salary of employee:\n");
        scanf("%d",&e[i].salary);
        e[i].gross=e[i].salary+(0.25*e[i].salary)+(0.75*e[i].salary);
    }
    printf("GENDER \t NAME \t DESIG \t DEPARTMENT \t BASIC \t GROSS\n");
    printf("--------------------------------------------------\n");
    for(i=0;i<n;i++)
    {
        printf("%c \t %s  %s  %s  %d  %d",e[i].gender,e[i].emp_name,e[i].designation,e[i].department,e[i].salary,e[i].gross);
        printf("\n");
    }
    printf("---------------------------------------------------\n");
    return 0;
}