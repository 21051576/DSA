#include<stdio.h>
int main()
{
  int r,c;
  printf("Enter row and column dimension");
  scanf("%d %d",&r,&c);
  int m[r][c];
  printf("Enter matrix elements");
  for(int i=0;i<r;i++)
  {
    for(int j=0;j<c;j++)
    {
      scanf("%d",&m[i][j]);
    }
  }
  
  int nz=0;
  for(int i=0;i<r;i++)
  {
    for(int j=0;j<c;j++)
    {
      if(m[i][j]!=0)
       nz++;
    }
  }
  
  int t[nz+1][3];
  t[0][0]=r;
  t[0][1]=c;
  t[0][2]=nz;
  int k=0;
  for(int i=0;i<r;i++)
  {
    for(int j=0;j<c;j++)
    {
      if(m[i][j]!=0)
      {
        k++;
        t[k][0]=i;
        t[k][1]=j;
        t[k][2]=m[i][j];
      }
    }
  }
  printf("\nSparse matrix in triplet form:\n");
  for(int i=0;i<=nz;i++)
  {
    for(int j=0;j<3;j++)
    {
      printf("%3d",t[i][j]);
    }
    printf("\n");
  }
  //transpose 
  int tt[nz+1][3];
  tt[0][0]=t[0][1];
  tt[0][1]=t[0][0];
  tt[0][2]=t[0][2];
  k=0;
  int l=0;
  while(k<c)
  {
    for(int i=1;i<=nz;i++)
    {
      if(t[i][1]==k)
      {
        l++;
        tt[l][0]=t[i][1];
        tt[l][1]=t[i][0];
        tt[l][2]=t[i][2];
      }
    }
    k++;
  }
  printf("\nTranspose of Sparse matrix in triplet form:\n");
  for(int i=0;i<=nz;i++)
  {
    for(int j=0;j<3;j++)
    {
      printf("%3d",tt[i][j]);
    }
    printf("\n");
  }
    return 0;
  

}