#include<stdio.h>
int main()
{
    int n;
    printf("enter the number of characters to be prsent in the string\n");
    scanf("%d",&n);
    char str[n];
    printf("enter the string\n");
    scanf("%s",&str);
    int i;
    for(i=n-1;i>=0;i--)
    {
        printf("%c",str[i]);
    }
    return 0;
}
