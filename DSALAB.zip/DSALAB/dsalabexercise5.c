#include<stdio.h>
int main()
{
    int n;
    printf("ENTER THE LIMIT OF THE ARRAY:\n");
    scanf("%d",&n);
    int arr[n];
    printf("ENTER THE ELEMENTS OF THE ARRAY:\n");
    int i;
    for(i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }
    int a,b,pos,pos1;
    printf("ENTER THE TWO NUMBERS;\n");
    scanf("%d",&a);
    scanf("%d",&b);
    for(i=0;i<n;i++)
    {
        if(arr[i]==a)
        {
            pos=i;
        }
    }
    for(i=0;i<n;i++)
    {
        if(arr[i]==b)
        {
            pos1=i;
        }
    }
    int c=0;
    for(i=pos;i<=pos1;i++)
    {
        c++;
    }
    printf("THE NUMBER OF ELEMENTS BETWEEN THE TWO GIVEN NUMBERS ARE:%d",c+1);
    return 0;
}