#include<stdio.h>
int main()
{
    int m,n;
    printf("enter the rows:");
    scanf("%d",&m);
    printf("enter the columns");
    scanf("%d",&n);
    int a[m][n];
    printf("enter the elements of array;\n");
    for(int i=0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
            scanf("%d",a[i][j]);
            a2[i]
        }
        printf("\n");
    }
for(i=0;i<m-1;i++)
{
    for(j=0;j-i-1;j++)
    {
        if(a[j]>a[j+1])
        {
            temp=a[j];
            a[j]=a[j+1];
            a[j+1]=temp;
        }
    }
}
}