#include<stdio.h>
int main()
{
  int r,c;
  printf("Enter no of rows:\n");
  scanf("%d",&r);
  printf("enter no of columns:\n");
  scanf("%d",&c);
  int arr[r][c];
  printf("Enter elemnts of matrix:\n");
  for(int i=0;i<r;i++)
  {
    for(int j=0;j<c;j++)
    {
      scanf("%d",&arr[i][j]);
    }
  }
  int k=0;//counter to calculate the no of non zero elements
  for(int i=0;i<r;i++)
  {
    for(int j=0;j<c;j++)
    {
      if(arr[i][j]!=0)
       k++;
    }
  }
  int t[c+1][3];
  t[0][0]=r;
  t[0][1]=c;
  t[0][2]=k;
  int p=0;
  for(int i=0;i<r;i++)
  {
    for(int j=0;j<c;j++)
    {
      if(arr[i][j]!=0)
      {
        p++;
        t[p][0]=i;
        t[p][1]=j;
        t[p][2]=arr[i][j];
      }
    }
  }
  printf("\nSparse matrix in triplet form:\n");
  for(int i=0;i<=k;i++)
  {
    for(int j=0;j<3;j++)
    {
      printf("%3d",t[i][j]);
    }
    printf("\n");
  }
  return 0;
}