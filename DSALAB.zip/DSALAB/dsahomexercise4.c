#include<stdio.h>
int main()
{
    int n;
    printf("enter the limit:\n");
    scanf("%d",&n);
    int arr[n],arr1[n];
    printf("enter the array elements:\n");
    int i,prev,next;
    for(i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
        arr1[i]=arr[i];
    }
    for(i=1;i<n;i++)
    {
        prev=i-1;
        next=i+1;
        arr[i]=arr1[prev]*arr[next];
    }
    printf("the array after changes is :\n");
    for(i=0;i<n;i++)
    {
        printf("%d ",arr[i]);
    }
}