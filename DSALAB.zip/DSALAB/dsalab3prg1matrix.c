#include<stdio.h>
int main()
{
    int r,c;
    printf("enter the no of rows:\n");
    scanf("%d",&r);
    printf("enter the number of columns:\n");
    scanf("%d",&c);
    int a[r][c],t[r][c],b[r][c],add[r][c],m[r][c];
    printf("enter the elemnts of the matrix:\n");
    int i,j,k;
    for(i=0;i<r;i++)
    {
        for(j=0;j<c;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    printf("enter the elemnets of another matrix:\n");
    for(i=0;i<r;i++)
    {
        for(j=0;j<c;j++)
        {
            scanf("%d",&b[i][j]);
        }
    }
    int n;
    printf("enter 1 for tranpose 2 for additon and 3 for multiplication 4 for determinant:\n");
    printf("enter your choice!!\n");
    scanf("%d",&n);
    switch(n)
    {
        case 1:
        for(i=0;i<r;i++)
        {
            for(j=0;j<c;j++)
            {
                t[j][i]=a[i][j];
            }
        }
        printf("displaying transpose:\n");
        for(i=0;i<r;i++)
        {
            for(j=0;j<c;j++)
            {
                printf("%d ",t[i][j]);
            }
            printf("\n");
        }
        break;
        case 2:
        for(i=0;i<r;i++)
        {
            for(j=0;j<c;j++)
            {
                add[i][j]=a[i][j]+b[i][j];
            }
        }
        for(i=0;i<r;i++)
        {
            for(j=0;j<c;j++)
            {
                printf("%d ",add[i][j]);
            }
            printf("\n");
        }
        break;
        case 3:
        for(i=0;i<r;i++)
        {
            for(j=0;j<c;j++)
            {
                for(k=0;k<c;k++)
                {
                    m[i][j]+=a[i][j]*b[j][i];
                }
                
            }
        }
        for(i=0;i<r;i++)
        {
            for(j=0;j<c;j++)
            {
                printf("%d ",m[i][j]);
                printf("\n");
            }
            printf("\n");
        }
        break;
        case 4:
        printf("enter a 3x3 matrix:\n ");
        int c[3][3],det;
        for(i=0;i<3;i++)
        {
            for(j=0;j<3;j++)
            {
                scanf("%d",&c[i][j]);
            }
        }
        for(i=0;i<3;i++)
        det = det + (c[0][i]*(c[1][(i+1)%3]*c[2][(i+2)%3] - c[1][(i+2)%3]*c[2][(i+1)%3]));
        printf("\nThe Determinant of the matrix is: %d\n\n",det);
        break;
        default:
        printf("sorry wrong choice!!");
        break;
    }
}