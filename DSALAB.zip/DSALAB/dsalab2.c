#include<stdio.h>
struct employee
{
    int empid;
    char emp_name[50];
    char designation[50];
    int salary;
};
int main()
{
    int n;
    printf("enter the limit:\n");
    scanf("%d",&n);
    struct employee e[n];
    int i;
    for(i=0;i<n;i++)
    {
        printf("Enter the eployee id employee\n",i);
        scanf("%d",&e[i].empid);
        printf("Enter the employee name:\n");
        scanf("%s",&e[i].emp_name);
        printf("enter the designation of the employee\n");
        scanf("%s",&e[i].designation);
        printf("enter the salary of employee:\n");
        scanf("%d",&e[i].salary);
    }
    printf("details taken succesfully\n");
    int k,j,temp;
    printf("enter the value of k\n");
    scanf("%d",&k);
    for(i=0;i<n-1;i++)
    {
        for(j=0;j<n-i-1;j++)
        {
            if(e[j].salary>e[j+1].salary)
            {
                temp=e[j].salary;
                e[j].salary=e[j+1].salary;
                e[j+1].salary=temp;

            }
        }
    }
    printf("the employee having highest salary is:\n");
    printf("EMPID \t EMPNAME \t DESIG \t SALARY\n");
    printf("%d \t %s \t %s \t %d ",e[n-k].empid,e[n-k].emp_name,e[n-k].designation,e[n-k].salary);
    return 0;
    
}